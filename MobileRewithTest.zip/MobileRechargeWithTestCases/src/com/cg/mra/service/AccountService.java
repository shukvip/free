package com.cg.mra.service;

import com.cg.mra.beans.Account;

public interface AccountService {
	public Account getAccountDetails(String mobileNo);
	public int rechargeAccount(String mobileno,double rechargeAmount);
	

}
