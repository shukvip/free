package com.capgemini.salesmanagement.service;

import java.util.HashMap;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.dao.SaleDAO;

public class SaleService implements ISaleService {
private static String catg;
private static String nme;
SaleDAO	daoref=new SaleDAO(); 
	@Override
	public HashMap<Integer, Sale> insertDetails(Sale sale) {
	
		// TODO Auto-generated method stub
		return daoref.insertSalesDetails(sale);
	}

	@Override
	public boolean validateProductCode(int productId) {
		if(productId==1001||productId==1002||productId==1003||productId==1004)
		// TODO Auto-generated method stub
		return true;
		else
			return false;
	}

	@Override
	public boolean validateQuantity(int qty) {
		if(qty>0 && qty<5)
			// TODO Auto-generated method stub
			return true;
			else
				return false;
		
	}

	@Override
	public boolean validateProductCat(String prodCat) {
		catg=prodCat;
		if(prodCat.equals("Electronics")||prodCat.equals("Toys"))
		// TODO Auto-generated method stub
		return true;
		else
			return false;
		
	}

	@Override
	public boolean validateProductName(String prodName) {
	nme=prodName;
		if(catg.equals("Electronics")&&(nme.equals("TV")||nme.equals("Samrt_phone")||nme.equals("Video_game")))
			// TODO Auto-generated method stub
			return true;
		else if(catg.equals("Toys")&&(nme.equals("Soft_toys")||nme.equals("Telescope")||nme.equals("Barbee_Doll")))
			
				return true;
		else
			return false;
	}

	@Override
	public boolean validateProductPrice(float price) {
		if(price<=200)
		return false;
		else
			return true;
	}
	

}
