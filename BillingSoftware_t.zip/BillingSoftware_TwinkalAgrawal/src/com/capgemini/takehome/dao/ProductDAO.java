package com.capgemini.takehome.dao;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.takehome.bean.Product;

import com.capgemini.takehome.util.CollectionUtill;

public class ProductDAO implements IProductDAO {
	Product pRef = null;

	@Override
	public Product getProductDetails(int productCode) {
		List<Product> product1 = new ArrayList<>(CollectionUtill.getProduct());
		// Checking Whether the product code is available or not
		for (Product p : product1) {
			// if product code is available then returning the values of product
			if (p.getId() == productCode)
				return p;

		}
		// if not found returning null
		return pRef;

	}

}
