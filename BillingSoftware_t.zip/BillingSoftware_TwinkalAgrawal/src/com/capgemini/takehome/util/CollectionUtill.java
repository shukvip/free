package com.capgemini.takehome.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.capgemini.takehome.bean.Product;

public class CollectionUtill {

	private static Map<Integer, Product> products = new HashMap<Integer, Product>();
	static {

		products.put(1001, new Product(1001, "iPhone", "Electronics", 35000, "Smart Phone"));
		products.put(1002, new Product(1002, "LEDTV", "Electronics", 45000, "Smart TV"));
		products.put(1003, new Product(1003, "Teddy", "Toys", 800, "Soft Toy"));
		products.put(1004, new Product(1004, "Telescope", "Toys", 5000, "Science Toy"));

	}

	// returning the values of product code
	public static List<Product> getProduct() {
		List<Product> product = new ArrayList<>(products.values());
		return product;
	}

}
