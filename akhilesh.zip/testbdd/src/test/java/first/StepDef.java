package first;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
   WebDriver driver;
	@Given("^Open the Firefox and launch the application$")
	public void open_the_Firefox_and_launch_the_application() throws Throwable {
		String projectLocation = System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver", projectLocation+"\\lib\\chromedriver.exe");
		driver =new ChromeDriver();
		driver.get("D:\\Users\\akhilsri\\Downloads\\New folder\\WorkingWithForms.html");
			   
	}
	@When("^Enter the Username 'User(\\d+)' and Password 'password(\\d+)'$")
	public void enter_the_Username_User_and_Password_password(int arg1, int arg2) throws Throwable {
		   
		String s="User"+arg1;
		driver.findElement(By.id("txtUserName")).sendKeys(s);
				    Thread.sleep(1000);
				    String s2="password"+arg2;
				    driver.findElement(By.name("txtPwd")).sendKeys(s2);
				      Thread.sleep(1000);
				      
			  // throw new PendingException();
	}
	@Then("^Reset the credential$")
	public void reset_the_credential() throws Throwable {
	    
		driver.findElement(By.name("reset")).click();
		
	 
}}
