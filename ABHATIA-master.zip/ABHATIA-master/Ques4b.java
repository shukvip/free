package ashishbhatia;
import ashishbhatia.Account;
class SavingAccount extends Account{

	SavingAccount(long accNum, double balance, Person accHolder) {
		super(accNum, balance, accHolder);
		// TODO Auto-generated constructor stub
	}
	
}
public class Ques4b {

}
