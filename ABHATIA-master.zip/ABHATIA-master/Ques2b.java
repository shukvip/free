package ashishbhatia;

public class Ques2b {
	 int n;
	public  void check(){
	if(n>0)
	{
		System.out.println("positive number");
	}
	else
	{
		System.out.println("negative no");
	}

}
	class Main {
	}
public static void main(String[] args) {
	Ques2b obj= new Ques2b();
	int N= Integer.parseInt(args[0]);
	obj.n=N;
	obj.check();
}
	}
