package com.capgemini.mobilePurchaseProject.bean;

public class Coustomer {
	private String coustomerName;
	private String mailId;
	private long phoneNumber;

}
