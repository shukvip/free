package com.capgemini.mobilePurchaseProject.bean;

public class MobileDetail {

}
