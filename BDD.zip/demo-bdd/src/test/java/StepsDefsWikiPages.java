import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepsDefsWikiPages {

	
	private WebDriver driver;
	@Before
	public void setup() {
		String projectLocation=System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver",projectLocation + "\\lib\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.navigate().to("http://en.wikipedia.org");
	}
	@After
	public void tearDown() {
		driver.quit();
		
	}
	@Given("^Enter search tern'(.*?)'$")
	public void enter_search_mecury(String searchTerm)throws Exception {
		System.out.println(searchTerm);
		
	}
	
	@When("^Do search$")
	public void do_search() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
	System.out.println("searching...");
	WebElement searchButton=driver.findElement(By.id("searchInput"));
	searchButton.submit();
	}

	@Then("^Multiple result are shown for(.*?)'$")
	public void multiple_result_are_shown_for_Mercury_may_refer_to(String result) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println(result);
	   
	}

	
		  
	


	
}
