public class PathPages {

	static String url = "file:///D:/training/0726-BDD-Central-Team/eclipse-workspace/Cucumber-Selenium-POM-Demo/scr/main/webapp/LoanApplicationPage.html";
	static String title = "Loan Application Page";
	
	public void goTo() {
		
		Browser.goTo(url);
	}

	public boolean isAt() {
		return Browser.title().equals(title);
	}

	
	
}
