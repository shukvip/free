package com.account.BankAccount;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.account.BankAccount.Service.AccountService;
import com.account.BankAccount.pojo.AccountDto;


@RestController
public class AccountController {
@Autowired
AccountService serviceref;
@RequestMapping(method=RequestMethod.GET,value="/account")
public List<AccountDto> findAll(){
	return serviceref.findAll();
}

@RequestMapping(method=RequestMethod.POST,value="/account")
public AccountDto create(@RequestBody AccountDto accountdto) {
	return serviceref.create(accountdto);
	}

@RequestMapping(method=RequestMethod.GET,value="/account/{id}")
public AccountDto get(@PathVariable int id) {
	return serviceref.get(id);
	}

@RequestMapping(method=RequestMethod.PUT,value="/account/{id}")
public AccountDto update(@PathVariable int id,@RequestBody AccountDto accountdto) {
	return serviceref.update(id, accountdto);
	}

@RequestMapping(method=RequestMethod.DELETE,value="/account/{id}")
public AccountDto delete(@PathVariable int id) {
	return serviceref.delete(id);
	}	
}
