package com.account.BankAccount.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.account.BankAccount.pojo.AccountDto;
import com.account.BankAccount.repo.AccountRepo;
@Service
public class AccountServiceImpl implements AccountService{
@Autowired
AccountRepo accountrepo;
	@Override
	public List<AccountDto> findAll() {
		// TODO Auto-generated method stub
		return accountrepo.findAll();
	}

	@Override
	public AccountDto create(AccountDto accountdto) {
		// TODO Auto-generated method stub
		return accountrepo.create(accountdto);
	}

	@Override
	public AccountDto get(int id) {
		// TODO Auto-generated method stub
		return accountrepo.get(id);
	}

	@Override
	public AccountDto update(int id, AccountDto accountdto) {
		// TODO Auto-generated method stub
		return accountrepo.update(id,accountdto);
	}

	@Override
	public AccountDto delete(int id) {
		// TODO Auto-generated method stub
		return accountrepo.delete(id);
	}

}
