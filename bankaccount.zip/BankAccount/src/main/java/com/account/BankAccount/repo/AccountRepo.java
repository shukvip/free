package com.account.BankAccount.repo;

import java.util.List;

import org.springframework.stereotype.Service;

import com.account.BankAccount.pojo.AccountDto;
@Service
public interface AccountRepo {
	public List<AccountDto>findAll(); 
	public AccountDto create(AccountDto accountdto);
	public  AccountDto get(int id);
	public AccountDto 
	update(int id,AccountDto productdto);
	public AccountDto delete(int id);
}
