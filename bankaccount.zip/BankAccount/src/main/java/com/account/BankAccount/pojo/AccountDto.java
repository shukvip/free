package com.account.BankAccount.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name="Account")

public class AccountDto {
public AccountDto() {
	// TODO Auto-generated constructor stub
}
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
private int id;
@Column(name="AccountNo.")
@NotNull
@Size(min = 2, max = 26)
//@Size(min = 2) It is also valid
/*@Size(min=1,message="name is required")
@Pattern(regexp="^[A-Z]{1}[a-z]+$")*/
private String AccNo;
@Column(name="Account holder name")
private String Name;
@Column(name="Balance")
private String Balance;

}
