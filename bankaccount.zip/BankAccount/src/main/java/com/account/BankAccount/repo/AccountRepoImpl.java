package com.account.BankAccount.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.account.BankAccount.pojo.AccountDto;

@Repository
@Transactional
public class AccountRepoImpl implements AccountRepo {
	@PersistenceContext
	private EntityManager entityManager;
	@Override
	public List<AccountDto> findAll() {
		// TODO Auto-generated method stub
		TypedQuery<AccountDto> query=entityManager.createQuery("select acco from AccountDto acco ", AccountDto.class);
		
		List<AccountDto> list= query.getResultList();
		System.out.println("inside find all:"+list);
	return list;
	}

	@Override
	@Transactional
	public AccountDto create(AccountDto accountdto) {
		// TODO Auto-generated method stub
		
		
			// TODO Auto-generated method stub	
		   entityManager.persist(accountdto);
			 return accountdto;
	}

	@Override
	@Transactional
	public AccountDto get(int id) {
		// TODO Auto-generated method stub
		AccountDto accountdto= entityManager.find(AccountDto.class, id);
		return accountdto;
	}

	@Override
	@Transactional
	public AccountDto update(int id, AccountDto accountdto) {
		// TODO Auto-generated method stub
		entityManager.merge(accountdto);
		entityManager.flush();
		return accountdto;
	}

	@Override
	public AccountDto delete(int id) {
		// TODO Auto-generated method stub
		AccountDto account= entityManager.find(AccountDto.class, id);
		entityManager.remove(account);
		entityManager.flush();
		return account;
	}

}
