package com.cg.product.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
@Entity
@Table(name="Products")
public class ProductDto {
	
	public ProductDto() {
		
	}
	@Id
	private String id;
	@Column(name="ProductName")
	@NotNull
	@Size(min = 2, max = 26)
	//@Size(min = 2) It is also valid
	
	
	
	private String pName;
	@Column(name="ProductModel")
	private String pModel;
	@Column(name="Price")
	private int price;
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public String getpModel() {
		return pModel;
	}
	public void setpModel(String pModel) {
		this.pModel = pModel;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
	
	
	
	
	
	
}
