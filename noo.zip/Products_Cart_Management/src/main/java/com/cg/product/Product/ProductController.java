package com.cg.product.Product;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.cg.product.exception.NamePatternException;
import com.cg.product.pojo.ProductDto;
import com.cg.product.service.ProductService;

@RestController
public class ProductController {

	@Autowired(required=true)
	private ProductService serviceref;
	
	
	@RequestMapping(value="/welcome",method=RequestMethod.GET)
	public String printHello() {
		return "Hello";
	}
	
	@RequestMapping(value="/getProduct",method=RequestMethod.GET,produces="application/json")
	public ProductDto getProduct(){
		ProductDto dto=new ProductDto();
		dto.setId("s01");
		dto.setpName("Iphone");
		dto.setpModel("6s");
		dto.setPrice(45000);
		return dto;
	}
	
	
	
	@RequestMapping(method=RequestMethod.GET,value="products")
	public List<ProductDto> findAll(){
		return serviceref.findAll();
	}
	
	@RequestMapping(method=RequestMethod.POST,value="products")
	public ProductDto create(@RequestBody ProductDto productdto) {
		return serviceref.create(productdto);
		}
	
	@RequestMapping(method=RequestMethod.GET,value="/products/{id}")
	public ProductDto get(@PathVariable String id) {
		return serviceref.get(id);
		}
	
	@RequestMapping(method=RequestMethod.PUT,value="/products/{id}")
	public ProductDto update(@PathVariable String id,@RequestBody ProductDto productdto) {
		return serviceref.update(id, productdto);
		}
	
	@RequestMapping(method=RequestMethod.DELETE,value="/products/{id}")
	public ProductDto delete(@PathVariable String id) {
		return serviceref.delete(id);
		}	
	

		

	@ResponseStatus(value=HttpStatus.NOT_FOUND,reason="Enter corrct name.")
	@ExceptionHandler({NamePatternException.class})
	public void handleNameException() {
		
	}
	
	
}
