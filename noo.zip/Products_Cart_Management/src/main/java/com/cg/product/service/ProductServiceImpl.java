package com.cg.product.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.product.exception.NamePatternException;
import com.cg.product.pojo.ProductDto;
import com.cg.product.repo.ProductRepo;

@Service
public class ProductServiceImpl implements ProductService {
	
	@Autowired(required=true)
	ProductRepo productrepo;
	public List<ProductDto> findAll(){
		return productrepo.findAll() ;	
	}
	public ProductDto create(ProductDto productdto) {
		
		String name=productdto.getpName();
		Pattern namePat=Pattern.compile("[A-Z][a-zA-Z]*"); 
		Matcher nameMa=namePat.matcher(name);
		if(nameMa.matches()==false) {
		throw new NamePatternException();
		}
		return productrepo.create(productdto);
	}
	public ProductDto get(String id) {
		return productrepo.get(id);
	}
	public ProductDto update(String id,ProductDto productdto) {
		return productrepo.update(id, productdto);
		
	}
	public ProductDto delete(String id) {
		return productrepo.delete(id);
		
	}
	
}
