package com.capgemini.trainer.service;

import java.util.HashMap;

import com.capgemini.trainer.dao.FeedbackDAO;
import com.capgemini.trainer.dao.IFeedbackDAO;
import com.capgemini.trainer.ui.Trainer;

public class FeedbackService implements IFeedbackService{
	
	IFeedbackDAO daoref=new FeedbackDAO();

	@Override
	public void addFeedback(Trainer trainer) {
		
		daoref.addFeedback(trainer);
		// TODO Auto-generated method stub
		
	}

	@Override
	public HashMap<Integer, Trainer> getTrainerList() {
		// TODO Auto-generated method stub
		return daoref.getTrainerList();
	}

}
