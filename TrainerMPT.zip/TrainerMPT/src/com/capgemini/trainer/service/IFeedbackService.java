package com.capgemini.trainer.service;

import java.util.HashMap;

import com.capgemini.trainer.ui.Trainer;

public interface IFeedbackService {
	
	public void addFeedback(Trainer trainer);
	public HashMap<Integer, Trainer> getTrainerList();

}
