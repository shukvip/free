package com.capgemini.trainer.exception;

public class ChoiceNotFoundException extends Exception{

}
