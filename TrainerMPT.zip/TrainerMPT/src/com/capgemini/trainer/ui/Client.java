package com.capgemini.trainer.ui;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.trainer.exception.ChoiceNotFoundException;
import com.capgemini.trainer.service.FeedbackService;
import com.capgemini.trainer.service.IFeedbackService;

public class Client {
	public static void main(String[] args) throws ChoiceNotFoundException {
	
		IFeedbackService serRef = new FeedbackService();
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the choice");
		int choice = sc.nextInt();
		if(choice>2)
		{
			throw new ChoiceNotFoundException();
		}
		Map<Integer,Trainer> maps= new HashMap<Integer,Trainer>();
		
		switch(choice)
		{
		case 1:
		{
			System.out.println("enter name");
			String name = sc.next();
			
			System.out.println("enter course name");
			String courseName = sc.next();
			
			System.out.println("enter startDate");
			String startDate = sc.next();
			
			System.out.println("enter endDate");
			String endDate = sc.next();
			
			System.out.println("enter rating");
			int rating = sc.nextInt();
			
			Trainer t = new Trainer(name, courseName, startDate, endDate, rating);
			serRef.addFeedback(t);
			maps=serRef.getTrainerList();
			System.out.println(maps);
			
			break;
		}
		case 2:
		{
			System.out.println("enter the rating");
			int n = sc.nextInt();
			maps=serRef.getTrainerList();
			for(Map.Entry<Integer, Trainer> m:maps.entrySet()) {
				if(m.getValue().getRating()==n) {
					System.out.println(m.getValue().getName());
				}
			}
		}
		
		
		}
		
		
		
	}

}
