package com.capgemini.trainer.dao;

import java.util.HashMap;

import com.capgemini.trainer.ui.Trainer;

public interface IFeedbackDAO {
	
	public void addFeedback(Trainer  trainer);
	public HashMap<Integer, Trainer> getTrainerList();

}
