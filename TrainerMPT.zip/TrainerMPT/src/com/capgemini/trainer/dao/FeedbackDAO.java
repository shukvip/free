package com.capgemini.trainer.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.trainer.ui.Trainer;
import com.capgemini.trainer.util.DBUtil;

public class FeedbackDAO implements IFeedbackDAO {
Map<Integer, Trainer> map;
	@Override
	public void addFeedback(Trainer trainer) {
		int FeedbackId= (int) (Math.random()*1000);
		
		map=DBUtil.feedbackList;
				
				map.put(FeedbackId,trainer);
		// TODO Auto-generated method stub
		
	}

	@Override
	public HashMap<Integer, Trainer> getTrainerList() {
		// TODO Auto-generated method stub
		return DBUtil.feedbackList;
	}

	
}
