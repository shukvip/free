import static org.junit.Assert.*;

public class Test {

	
	@org.junit.Before
	void Before()
	{
		
	}
	@org.junit.Test
	public void test() {
		
		
		
		
	}
	@org.junit.After
	void After()
	{
		
	}

}
