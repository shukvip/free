package com.cg.dao.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.dao.CarDAO;
import com.cg.dto.CarDTO;

//TODO 1 Import appropriate classes based on following TODOs

//TODO 2 Implement appropriate Interface

public class MapDAOImpl implements CarDAO {

	Map<Integer, CarDTO> carmap = null;

	public MapDAOImpl() {
		carmap = new HashMap<Integer, CarDTO>();
		
		CarDTO car1=new CarDTO();
		car1.setId(1);
		car1.setMake("Mahindra ");
        car1.setModel("XUV 500");
        car1.setModelYear("2018");
        carmap.put(car1.getId(), car1);
		
        CarDTO car2=new CarDTO();
		car2.setId(2);
		car2.setMake("Maruti Suzuki ");
        car2.setModel("Swift DZire");
        car2.setModelYear("2017");
        carmap.put(car2.getId(), car2); 
	}

	@Override
	public void create(CarDTO car) {
		CarDTO c = carmap.putIfAbsent(car.getId(), car);
		if (c == null)
			System.out.println("Created");
	}

	@Override
	public void delete(String[] ids) {
		for (String s : ids) {
			CarDTO c = carmap.remove(Integer.parseInt(s));
			System.out.println(c.getId() + "Removed");
		}
	}

	@Override
	public void update(CarDTO car) {
		CarDTO c = carmap.put(car.getId(), car);
		if (c != null)
			System.out.println("Updated");

	}

	@Override
	public List<CarDTO> findAll() {
		List<CarDTO> carList = new ArrayList<CarDTO>(carmap.values());
		/*for (Map.Entry<Integer, CarDTO> cars : carmap.entrySet()) {
			carList.add(cars.getValue());
		}*/

		return carList;
	}

	@Override
	public CarDTO findById(int id) {
		CarDTO car =null;
		car = carmap.get(id);
		return car;
	}
}
